export const config = {
    API_BASE_URL : 'https://taxi.becknprotocol.io/',
    SELF_HOST_NAME: 'taxi.becknprotocol.io' ,
};
